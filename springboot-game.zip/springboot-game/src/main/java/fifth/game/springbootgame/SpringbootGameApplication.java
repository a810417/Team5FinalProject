package fifth.game.springbootgame;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootGameApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootGameApplication.class, args);
	}

}
