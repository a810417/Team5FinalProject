package fifth.game.springbootgame;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootGameApplicationTests {

	@Test
	void contextLoads() {
	}

}
