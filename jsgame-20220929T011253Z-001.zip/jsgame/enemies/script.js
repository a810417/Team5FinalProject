/**@type {HTMLCanvasElement} */
//上面那行告訴VSCODE這是一個canvas project
const canvas = document.getElementById("canvas1")
const ctx = canvas.getContext("2d")
canvas.width = 500;
canvas.height = 1000;
//決定enemy數量
const numberOfEnemies = 100
const enemiesArray = []

let gameFrame = 0

class Enemy {
    constructor() {
        this.image = new Image()
        this.image.src = "enemy1.png"
        //隨機enemy的移動速度(希望移動速度是2或是-2,概念是(0~1*4)-2)
        // this.speed = Math.random() * 4 - 2
        //sprite框框
        this.spriteWidth = 293
        this.spriteHeight = 155
        this.width = this.spriteWidth / 2.5
        this.height = this.spriteHeight / 2.5
        //隨機製造enemy生成地點,因為有用到this.width所以要放他後面
        this.x = Math.random() * (canvas.width - this.width)
        this.y = Math.random() * (canvas.height - this.height)
        this.frame = 0
        //1:48:55
        this.flapSpeed = Math.floor(Math.random() * 3 + 1)
    }
    //enemy移動方式
    update() {
        //0~3-1.5讓他保持在-1.5~1.5移動
        this.x += Math.random() * 15 - 7.5
        this.y += Math.random() * 10 - 5
        if (gameFrame % 2 === 0) {
            //ternary operator?????
            //animate sprites
            this.frame > 4 ? this.frame = 0 : this.frame++
        }
    }
    //畫出上面設定的enemy
    draw() {

        //2~5欄位代表從圖片的0,0(左上角)開始畫出SPRITE框框
        //第2欄位代表0~5*293去框1~6
        ctx.drawImage(this.image, this.frame * this.spriteWidth, 0, this.spriteWidth, this.spriteHeight, this.x, this.y, this.width, this.height)
    }
}
//一次製造一堆enemy
for (let i = 0; i < numberOfEnemies; i++) {
    //PUSH方法會一直PUSH到ARRAY的底
    enemiesArray.push(new Enemy())
}

function animate() {
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    //enemies陣列的enemies執行畫出+移動
    enemiesArray.forEach(enemy => {
        enemy.draw()
        enemy.update()
    })
    gameFrame++
    //再把animate叫近來重新執行一遍=這個方法一直這個方法一直重複執行
    requestAnimationFrame(animate)
}
animate()

//1:52:00