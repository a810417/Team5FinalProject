import platform from "../images/platform.png"
import hills from "../images/hills.png"
import background from "../images/background.png"
import platformSmallTall from "../images/platformSmallTall.png"

import spriteRunLeft from "../images/spriteRunLeft.png"
import spriteRunRight from "../images/spriteRunRight.png"
import spriteStandLeft from "../images/spriteStandLeft.png"
import spriteStandRight from "../images/spriteStandRight.png"

import podium from "../images/podium.png"

console.log(platform)
const canvas = document.querySelector("canvas")
const c = canvas.getContext("2d")

canvas.width = 1280
canvas.height = 576

const gravity = 1.8

let scrollOffset = 0

var ctx = canvas.getContext('2d'),
  startTime = new Date(),
  lastTime = null,  // for scale
  isRunning = false
let timeElapsed = null;
let score = null;
// FPS = 1000 / 60,
// x = 0,
// dx = 4; // ideal frame rate

function loop(timeStamp) {

  if (!startTime) startTime = timeStamp;


  // var timeDiff = lastTime ? timeStamp - lastTime : FPS,
  var timeElapsed = timeStamp - startTime;
  // timeScale = timeDiff / FPS; // adjust variations in frame rates

  // lastTime = timeStamp;

  // ctx.clearRect(0, 0, canvas.width, canvas.height);

  // do your stuff using timeScale, ie:
  // pos.x += velocity.x * timeScale
  // x += dx * timeScale;
  // if (x < 0 || x > canvas.width - 1) dx = -dx;

  // ctx.fillRect(x, 0, 8, 8);
  let test = (timeElapsed * 0.001).toFixed(3).toString();

  score = test;
  ctx.fillText(score, 1130, 50);
  // ctx.fillText(timeScale.toFixed(1), 10, 90);


  if (isRunning) requestAnimationFrame(loop);
  ctx.font = "35px sans-serif";
  ctx.fillStyle = "	#FFFFFF"
}





//玩家位置大小
class Player {
  constructor() {
    this.speed = 10
    this.position = {
      x: 100,
      y: 100,
    }
    this.velocity = {
      x: 0,
      y: 5
    }
    this.width = 66
    this.height = 150

    this.image = createImage(spriteStandRight)
    this.frames = 0
    this.sprites = {
      stand: {
        right: createImage(spriteStandRight),
        left: createImage(spriteStandLeft),
        cropWidth: 177,
        width: 66
      }, run: {
        right: createImage(spriteRunRight),
        left: createImage(spriteRunLeft),
        cropWidth: 341,
        width: 127.875
      }
    }
    this.currentSprite = this.sprites.stand.right
    this.currentCropWidth = 177
  }

  draw() {
    //數字為spritesheet
    c.drawImage(
      this.currentSprite,
      this.currentCropWidth * this.frames,
      0,
      this.currentCropWidth,
      400,
      this.position.x,
      this.position.y,
      this.width,
      this.height
    )
  }

  update() {
    this.frames++
    //角色輪播
    if (this.frames > 59 && (this.currentSprite === this.sprites.stand.right || this.currentSprite === this.sprites.stand.left))
      this.frames = 0
    else if (this.frames > 29 && (this.currentSprite === this.sprites.run.right || this.currentSprite === this.sprites.run.left))
      this.frames = 0
    this.draw()
    this.position.y += this.velocity.y
    this.position.x += this.velocity.x

    //遇到地板不再受到地心引力影響
    if (this.position.y + this.height + this.velocity.y <= canvas.height)
      this.velocity.y += gravity


  }
}

//平台位置大小
class Platform {
  constructor({ x, y, image }) {
    this.position = {
      x: x,  //:後面可省略
      y: y,
    }

    this.image = image
    this.width = image.width
    this.height = image.height


  }

  draw() {
    c.drawImage(this.image, this.position.x, this.position.y)

  }

}
//背景物件
class GenericObject {
  constructor({ x, y, image }) {
    this.position = {
      x: x,  //:後面可省略
      y: y,
    }

    this.image = image
    this.width = image.width
    this.height = image.height


  }

  draw() {
    c.drawImage(this.image, this.position.x, this.position.y)

  }

}




//時鐘



function createImage(imageSrc) {
  const image = new Image()
  image.src = imageSrc
  return image
}

let platformImg = createImage(platform)
let smalltallplatform = createImage(platformSmallTall)

let player = new Player()
let platforms = [

]
let genericObject = [

]

//預設按鈕為false,keydown才變true
let keys = {
  right: {
    pressed: false
  },
  left: {
    pressed: false
  }
}



function init() {
  platformImg = createImage(platform)
  smalltallplatform = createImage(platformSmallTall)

  player = new Player()
  platforms = [
    new Platform({ x: 2370, y: 270, image: smalltallplatform }),
    new Platform({ x: 3150, y: 455, image: smalltallplatform }),
    new Platform({ x: 3150, y: 350, image: smalltallplatform }),
    new Platform({ x: 3150, y: 250, image: smalltallplatform }),
    new Platform({ x: 3150, y: 455, image: smalltallplatform }),
    new Platform({ x: 0, y: 455, image: platformImg }),
    new Platform({ x: platformImg.width - 290, y: 455, image: platformImg }),
    new Platform({ x: 1100, y: 455, image: smalltallplatform }),
    new Platform({ x: 1730, y: 455, image: platformImg }),
    new Platform({ x: 2080, y: 455, image: platformImg }),
    new Platform({ x: 3150, y: 150, image: smalltallplatform }),
    new Platform({ x: 3600, y: 455, image: platformImg }),
    new Platform({ x: 4400, y: 455, image: smalltallplatform }),
    new Platform({ x: 5000, y: 455, image: platformImg }),
    new Platform({ x: 9900, y: 455, image: createImage(podium) }),
  ]
  genericObject = [
    new GenericObject({ x: -1, y: -1, image: createImage(background) }),
    new GenericObject({ x: -1, y: -1, image: createImage(hills) })
  ]

  //預設按鈕為false, keydown才變true
  keys = {
    right: {
      pressed: false
    },
    left: {
      pressed: false
    }
  }

  scrollOffset = 0
}

//移動
function animate() {
  requestAnimationFrame(animate)
  //框框
  c.fillStyle = "white"
  c.fillRect(0, 0, canvas.width, canvas.height)

  genericObject.forEach(genericObject => {
    genericObject.draw()
  })

  platforms.forEach(platform => {
    platform.draw()
  })
  player.update()


  //設置玩家移動範圍(scroll)
  if (keys.right.pressed && player.position.x < 700) {
    player.velocity.x = player.speed
  } else if ((keys.left.pressed && player.position.x > 100) || keys.left.pressed && scrollOffset === 0 && player.position.x > 0) {
    player.velocity.x = -player.speed
  } else {
    player.velocity.x = 0

    if (keys.right.pressed) {
      scrollOffset += player.speed
      platforms.forEach(platform => {
        platform.position.x -= player.speed
      })
      genericObject.forEach(genericObject => {
        genericObject.position.x -= player.speed
      })
    } else if (keys.left.pressed && scrollOffset > 0) {
      scrollOffset -= player.speed
      platforms.forEach(platform => {
        platform.position.x += player.speed
      })
      genericObject.forEach(genericObject => {
        genericObject.position.x += player.speed
      })
    }
  }
  //
  platforms.forEach(platform => {
    if (player.position.y + player.height <= platform.position.y && player.position.y + player.height + player.velocity.y >= platform.position.y && player.position.x + player.width >= platform.position.x && player.position.x <= platform.position.x + platform.width) {
      player.velocity.y = 0
    }
  })

  //移動邏輯
  if (keys.right.pressed && lastKey === "right" && player.currentSprite !== player.sprites.run.right
  ) {
    player.frames = 1
    player.currentSprite = player.sprites.run.right
    player.currentCropWidth = player.sprites.run.cropWidth
    player.width = player.sprites.run.width
  } else if (keys.left.pressed && lastKey === "left" && player.currentSprite !== player.sprites.run.left
  ) {
    player.currentSprite = player.sprites.run.left
    player.currentCropWidth = player.sprites.run.cropWidth
    player.width = player.sprites.run.width
  } else if (!keys.left.pressed && lastKey === "left" && player.currentSprite !== player.sprites.stand.left
  ) {
    player.currentSprite = player.sprites.stand.left
    player.currentCropWidth = player.sprites.stand.cropWidth
    player.width = player.sprites.stand.width
  } else if (!keys.right.pressed && lastKey === "right" && player.currentSprite !== player.sprites.stand.right
  ) {

    player.currentSprite = player.sprites.stand.right
    player.currentCropWidth = player.sprites.stand.cropWidth
    player.width = player.sprites.stand.width

  }
  //獲勝條件
  if (scrollOffset > 4500) {
    // console.log(timeStamp - startTime);
    isRunning = false

    win()



  }
  //失敗條件
  if (player.position.y > canvas.height + 50) {
    alert("TRY AGAIN!!")
    init()
  }
}

init()
animate()
let lastKey
//移動
addEventListener("keydown", ({ code }) => {
  console.log(code)
  switch (code) {
    case "KeyA":
      console.log("left")
      keys.left.pressed = true
      lastKey = "left"
      break

    case "KeyS":
      console.log("down")
      break

    case "KeyD":
      console.log("right")
      keys.right.pressed = true
      lastKey = 'right'
      break

    case "Space":
      console.log("up")
      player.velocity.y -= 20
      break
  }
})

addEventListener("keyup", ({ code }) => {
  switch (code) {
    case "KeyA":
      console.log("left")
      keys.left.pressed = false

      break

    case "KeyS":
      console.log("down")
      break

    case "KeyD":
      console.log("right")
      keys.right.pressed = false

      break

    case "Space":
      console.log("up")
      player.velocity.y -= 10
      break
  }
})

function win() {

  //框框
  c.fillText(`YOU WIN!! ${score}`, 640, 250)
  player.position.x == 10000
  c.fillStyle = "black"
  player.speed = 0
  removeEventListener("click", "keydown", ({ code }) => {
    console.log(code)
    switch (code) {
      case "KeyA":
        console.log("left")
        keys.left.pressed = true
        lastKey = "left"
        break

      case "KeyS":
        console.log("down")
        break

      case "KeyD":
        console.log("right")
        keys.right.pressed = true
        lastKey = 'right'
        break

      case "Space":
        console.log("up")
        player.velocity.y -= 20
        break
    }
  })
  // cancelAnimationFrame(loop)
  c.strokeStyle = "#D50A17" //設定文字邊框


}


window.onload = function () {
  if (scrollOffset > 3500) {
    isRunning = false
    console.log(timeElapsed * 0.001)
  } else {
    startTime = lastTime = null;
    isRunning = true;
    timer = requestAnimationFrame(loop)
  }

};

